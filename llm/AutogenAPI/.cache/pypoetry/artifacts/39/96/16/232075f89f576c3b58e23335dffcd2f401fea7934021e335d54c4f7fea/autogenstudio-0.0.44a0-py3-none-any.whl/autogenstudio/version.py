VERSION = "0.0.44a"
__version__ = VERSION
APP_NAME = "autogenstudio"
